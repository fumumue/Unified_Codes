//! Dense Gaussian elimination over GF(2^m).
use crate::field::{BinaryField, FieldError};

#[derive(Debug, Clone)]
pub struct Matrix { rows: usize, cols: usize, data: Vec<u16> }
impl Matrix {
    pub fn new(rows: usize, cols: usize, data: Vec<u16>) -> Result<Self, &'static str> {
        if data.len() != rows.checked_mul(cols).ok_or("matrix size overflow")? { return Err("matrix data length mismatch"); }
        Ok(Self { rows, cols, data })
    }
    pub fn zeros(rows: usize, cols: usize) -> Self { Self { rows, cols, data: vec![0; rows*cols] } }
    pub fn rows(&self) -> usize { self.rows }
    pub fn cols(&self) -> usize { self.cols }
    pub fn get(&self, r: usize, c: usize) -> u16 { self.data[r*self.cols+c] }
    pub fn set(&mut self, r: usize, c: usize, x: u16) { self.data[r*self.cols+c] = x; }
    pub fn rank(&self, f: BinaryField) -> Result<usize, FieldError> {
        let mut a = self.data.clone();
        let mut rank = 0;
        for col in 0..self.cols {
            let Some(pivot) = (rank..self.rows).find(|&r| a[r*self.cols+col] != 0) else { continue; };
            if pivot != rank { for c in 0..self.cols { a.swap(pivot*self.cols+c, rank*self.cols+c); } }
            let inv = f.inverse(a[rank*self.cols+col])?;
            for c in col..self.cols { let i=rank*self.cols+c; a[i]=f.mul(a[i],inv); }
            for r in 0..self.rows {
                if r == rank { continue; }
                let factor=a[r*self.cols+col];
                if factor == 0 { continue; }
                for c in col..self.cols { let p=a[rank*self.cols+c]; let i=r*self.cols+c; a[i]^=f.mul(factor,p); }
            }
            rank += 1;
            if rank == self.rows { break; }
        }
        Ok(rank)
    }
}

#[cfg(test)] mod tests {
    use super::*;
    #[test] fn rank_over_gf8() {
        let f=BinaryField::new(3,0b1011).unwrap();
        let a=Matrix::new(3,3,vec![1,2,3, 2,4,6, 0,0,1]).unwrap();
        assert_eq!(a.rank(f).unwrap(),2);
    }
}
