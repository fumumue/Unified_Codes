//! Arithmetic in GF(2^m), using polynomial-basis representation.
//! Unlike the C log/antilog tables, multiplication does not require a
//! primitive polynomial; any irreducible modulus is accepted.

use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FieldError {
    InvalidDegree(u32),
    InvalidModulus { m: u32, modulus: u32 },
    ReducibleModulus(u32),
    DivisionByZero,
}

impl fmt::Display for FieldError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidDegree(m) => write!(f, "m must be in 1..=12 (got {m})"),
            Self::InvalidModulus { m, modulus } => write!(f, "modulus 0x{modulus:x} does not have degree {m}"),
            Self::ReducibleModulus(p) => write!(f, "modulus 0x{p:x} is reducible over GF(2)"),
            Self::DivisionByZero => write!(f, "division by zero in finite field"),
        }
    }
}

impl std::error::Error for FieldError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BinaryField {
    m: u32,
    modulus: u32,
    order: u32,
    mask: u32,
}

impl BinaryField {
    pub fn new(m: u32, modulus: u32) -> Result<Self, FieldError> {
        if !(1..=12).contains(&m) { return Err(FieldError::InvalidDegree(m)); }
        if modulus >> m != 1 || modulus & 1 == 0 {
            return Err(FieldError::InvalidModulus { m, modulus });
        }
        if !is_irreducible(modulus, m) { return Err(FieldError::ReducibleModulus(modulus)); }
        let order = 1u32 << m;
        Ok(Self { m, modulus, order, mask: order - 1 })
    }

    pub fn degree(self) -> u32 { self.m }
    pub fn modulus(self) -> u32 { self.modulus }
    pub fn order(self) -> u32 { self.order }
    pub fn add(self, a: u16, b: u16) -> u16 { (u32::from(a ^ b) & self.mask) as u16 }

    pub fn mul(self, a: u16, b: u16) -> u16 {
        let mut x = u32::from(a) & self.mask;
        let mut y = u32::from(b) & self.mask;
        let mut z = 0u32;
        while y != 0 {
            if y & 1 != 0 { z ^= x; }
            y >>= 1;
            x <<= 1;
            if x & self.order != 0 { x ^= self.modulus; }
        }
        (z & self.mask) as u16
    }

    pub fn pow(self, a: u16, mut n: u64) -> u16 {
        let mut base = a;
        let mut acc = 1u16;
        while n != 0 {
            if n & 1 != 0 { acc = self.mul(acc, base); }
            n >>= 1;
            if n != 0 { base = self.mul(base, base); }
        }
        acc
    }

    pub fn inverse(self, a: u16) -> Result<u16, FieldError> {
        if a == 0 { return Err(FieldError::DivisionByZero); }
        Ok(self.pow(a, u64::from(self.order - 2)))
    }

    pub fn div(self, a: u16, b: u16) -> Result<u16, FieldError> {
        Ok(self.mul(a, self.inverse(b)?))
    }

    /// True when x generates the multiplicative group. This is stronger than
    /// irreducibility and is only needed by algorithms that use log tables.
    pub fn is_primitive_element(self, x: u16) -> bool {
        if x == 0 { return false; }
        let target = self.order - 1;
        let mut y = 1u16;
        for i in 1..=target {
            y = self.mul(y, x);
            if y == 1 { return i == target; }
        }
        false
    }
}

fn degree(p: u32) -> i32 { if p == 0 { -1 } else { 31 - p.leading_zeros() as i32 } }

fn poly_rem(mut a: u32, b: u32) -> u32 {
    let db = degree(b);
    while a != 0 && degree(a) >= db { a ^= b << (degree(a) - db); }
    a
}

fn is_irreducible(p: u32, m: u32) -> bool {
    // A degree-m polynomial is reducible iff it has a monic factor of degree
    // at most floor(m/2). Exhaustive trial division is tiny for m <= 12.
    for d in 1..=m / 2 {
        let start = 1u32 << d;
        for low in 0..start {
            if low & 1 == 0 { continue; }
            let candidate = start | low;
            if poly_rem(p, candidate) == 0 { return false; }
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn gf8_known_products() {
        let f = BinaryField::new(3, 0b1011).unwrap(); // x^3 + x + 1
        assert_eq!(f.mul(2, 4), 3); // x * x^2 = x^3 = x + 1
        assert_eq!(f.mul(7, 7), 3);
        for a in 1..8 { assert_eq!(f.mul(a, f.inverse(a).unwrap()), 1); }
    }
    #[test] fn rejects_reducible_modulus() {
        assert!(matches!(BinaryField::new(3, 0b1111), Err(FieldError::ReducibleModulus(_))));
    }
    #[test] fn primitive_check() {
        let f = BinaryField::new(3, 0b1011).unwrap();
        assert!(f.is_primitive_element(2));
        assert!(!f.is_primitive_element(1));
    }
}
