//! Classical-code port. Modules will be migrated from the C implementation
//! one algorithm at a time, with reference-vector tests before integration.
