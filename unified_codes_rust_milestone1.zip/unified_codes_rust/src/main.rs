mod field;
mod matrix;
mod polynomial;
mod classical;
mod ag;

use field::BinaryField;
use std::process::ExitCode;

fn usage() {
    println!("unified_codes (Rust migration)\n\nUSAGE:\n  unified_codes --help\n  unified_codes --check-field --m M --poly POLY\n  unified_codes --field-info --m M --poly POLY\n\nPOLY is an integer such as 0x100b or 4107. The modulus must be irreducible.\n\nMigration status: finite-field / polynomial / matrix foundation is being ported;\nclassical-code and AG-code engines are not yet ported in this milestone.");
}
fn parse_u32(s: &str) -> Result<u32,String> {
    if let Some(v)=s.strip_prefix("0x").or_else(||s.strip_prefix("0X")) { u32::from_str_radix(v,16).map_err(|e|e.to_string()) }
    else { s.parse::<u32>().map_err(|e|e.to_string()) }
}
fn run(args: &[String]) -> Result<(),String> {
    if args.is_empty() || args.iter().any(|x| x=="--help" || x=="-h") { usage(); return Ok(()); }
    let mut m=None; let mut poly=None;
    let mut i=0;
    while i<args.len() {
        match args[i].as_str() {
            "--m" => { i+=1; m=Some(args.get(i).ok_or("--m requires a value")?.parse::<u32>().map_err(|e|e.to_string())?); },
            "--poly" => { i+=1; poly=Some(parse_u32(args.get(i).ok_or("--poly requires a value")?)?); },
            "--check-field" | "--field-info" => {},
            other => return Err(format!("unknown option: {other}")),
        }
        i+=1;
    }
    let m=m.ok_or("missing --m")?; let poly=poly.ok_or("missing --poly")?;
    let f=BinaryField::new(m,poly).map_err(|e|e.to_string())?;
    println!("GF(2^{})",f.degree());
    println!("order       : {}",f.order());
    println!("modulus     : 0x{:x}",f.modulus());
    println!("irreducible : yes");
    println!("alpha=0x2 primitive : {}",f.is_primitive_element(2));
    Ok(())
}
fn main() -> ExitCode {
    match run(&std::env::args().skip(1).collect::<Vec<_>>()) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => { eprintln!("error: {e}\nUse --help for usage."); ExitCode::from(2) }
    }
}
