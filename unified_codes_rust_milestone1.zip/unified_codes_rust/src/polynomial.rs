//! Dense low-to-high coefficient polynomials over GF(2^m).
use crate::field::{BinaryField, FieldError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Polynomial { coeffs: Vec<u16> }

impl Polynomial {
    pub fn new(mut coeffs: Vec<u16>) -> Self {
        while coeffs.len() > 1 && coeffs.last() == Some(&0) { coeffs.pop(); }
        if coeffs.is_empty() { coeffs.push(0); }
        Self { coeffs }
    }
    pub fn zero() -> Self { Self::new(vec![0]) }
    pub fn one() -> Self { Self::new(vec![1]) }
    pub fn coeffs(&self) -> &[u16] { &self.coeffs }
    pub fn degree(&self) -> Option<usize> { if self.is_zero() { None } else { Some(self.coeffs.len()-1) } }
    pub fn is_zero(&self) -> bool { self.coeffs.len() == 1 && self.coeffs[0] == 0 }
    pub fn add(&self, rhs: &Self) -> Self {
        let n = self.coeffs.len().max(rhs.coeffs.len());
        let mut out = vec![0; n];
        for (i, v) in out.iter_mut().enumerate() {
            *v = self.coeffs.get(i).copied().unwrap_or(0) ^ rhs.coeffs.get(i).copied().unwrap_or(0);
        }
        Self::new(out)
    }
    pub fn scale(&self, f: BinaryField, scalar: u16) -> Self {
        Self::new(self.coeffs.iter().map(|&x| f.mul(x, scalar)).collect())
    }
    pub fn mul(&self, f: BinaryField, rhs: &Self) -> Self {
        if self.is_zero() || rhs.is_zero() { return Self::zero(); }
        let mut out = vec![0u16; self.coeffs.len() + rhs.coeffs.len() - 1];
        for (i, &a) in self.coeffs.iter().enumerate() {
            for (j, &b) in rhs.coeffs.iter().enumerate() { out[i+j] ^= f.mul(a,b); }
        }
        Self::new(out)
    }
    pub fn evaluate(&self, f: BinaryField, x: u16) -> u16 {
        self.coeffs.iter().rev().fold(0, |acc, &c| f.mul(acc, x) ^ c)
    }
    pub fn div_rem(&self, f: BinaryField, divisor: &Self) -> Result<(Self, Self), FieldError> {
        let dd = divisor.degree().ok_or(FieldError::DivisionByZero)?;
        if self.degree().unwrap_or(0) < dd { return Ok((Self::zero(), self.clone())); }
        let inv_lead = f.inverse(divisor.coeffs[dd])?;
        let mut rem = self.coeffs.clone();
        let mut quo = vec![0u16; rem.len() - dd];
        while !(rem.len() == 1 && rem[0] == 0) && rem.len() - 1 >= dd {
            let shift = rem.len() - 1 - dd;
            let factor = f.mul(*rem.last().unwrap(), inv_lead);
            quo[shift] = factor;
            for j in 0..=dd { rem[shift+j] ^= f.mul(factor, divisor.coeffs[j]); }
            while rem.len() > 1 && rem.last() == Some(&0) { rem.pop(); }
        }
        Ok((Self::new(quo), Self::new(rem)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn multiply_and_divide() {
        let f = BinaryField::new(3, 0b1011).unwrap();
        let a = Polynomial::new(vec![1,2,1]);
        let b = Polynomial::new(vec![3,1]);
        let p = a.mul(f, &b);
        let (q,r) = p.div_rem(f,&b).unwrap();
        assert_eq!(q,a); assert!(r.is_zero());
        assert_eq!(a.evaluate(f, 1), 0);
    }
}
