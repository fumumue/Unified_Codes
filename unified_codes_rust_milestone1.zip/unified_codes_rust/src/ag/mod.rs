//! Algebraic-geometry-code port. Curve, Newton polygon, places, Riemann-Roch
//! spaces and decoders remain to be migrated and independently verified.
