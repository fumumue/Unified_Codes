# unified_codes — Rust migration

This is a staged Rust rewrite of the supplied `unified_codes(20261127-180130).c`.
The original C source is intentionally left untouched. The Rust project is kept
separate so the C implementation remains a reference oracle during migration.

## Current milestone

Implemented in Rust:

- `GF(2^m)` arithmetic in polynomial-basis representation (`m <= 12`, matching
the current C source's stated bound).
- Validation that the supplied binary modulus is irreducible. A primitive
  polynomial is **not** required for field arithmetic.
- Multiplicative inverse, division, exponentiation and primitive-element check.
- Dense polynomial arithmetic over `GF(2^m)`.
- Dense matrix rank by Gaussian elimination over `GF(2^m)`.
- A small CLI for checking a field definition.

Not yet ported: BCH/Golay/Goppa/Alternant/Srivastava/RM/GRS/Gabidulin/product/
concatenated engines; AG curve normalization, Newton polygon/place machinery,
Riemann–Roch basis construction, and FR/BMS/VOTE/BASIC decoders. The current
Rust executable is therefore a foundation, **not a feature-complete replacement**
for the C executable.

## Build

Requires Rust stable (edition 2021), no third-party crates:

```sh
cargo test
cargo build --release
```

## Usage

```sh
cargo run -- --help
cargo run -- --check-field --m 3 --poly 0x0b
```

Expected field summary for the example:

```text
GF(2^3)
order       : 8
modulus     : 0xb
irreducible : yes
alpha=0x2 primitive : true
```

## Migration policy

1. Keep the C source as the reference implementation; do not replace it yet.
2. Port shared arithmetic and verify it independently first.
3. Port classical codes in isolated modules, comparing deterministic outputs
   against C for the same parameters and seeds.
4. Port AG geometry and basis construction separately from each decoder.
5. Preserve CLI compatibility only after each corresponding code path passes
   reference tests. Do not label a path complete merely because it compiles.

## Important compatibility note

The C implementation uses global log/antilog tables and its `gf_init` expects
the chosen modulus to make `x` primitive. The Rust field layer instead uses
carry-less polynomial multiplication and accepts any irreducible modulus. This
is mathematically more general, but code paths that depend on logarithm tables
will need an explicit primitive-element/log-table adapter during their port.
